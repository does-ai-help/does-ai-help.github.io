# Release history

## 2026.10.15 - Author affiliation presentation

- Added Jit Team as the human co-author's institute affiliation on the PDF title page and web front-page byline.
- Affiliation-only presentation patch; article findings, source database, evidence cutoff and final editorial review are unchanged. The final October checkpoint tag and version 2026.10.14 artifacts remain intact.

## 2026.10.14 - Final October release

- Completed a final AI-assisted editorial self-review of the entire main article, with targeted primary-source checks and a documented review scope.
- Distinguished randomized experiments from the customer-support quasi-experiment; included mixed subgroup quality outcomes and learning evidence.
- Clarified the scope of the mathematical translation critique without adjudicating proof correctness.
- Closed the October baseline at the unchanged 13 October 2026 cutoff. November preparation proceeds on a separate branch.
- Pre-publication access checks defer the exact not-yet-created GitHub release URL; post-publication verification checks it. Reference links remain subject to the strict access gate.

## 2026.10.13 - Publication baseline and navigation

- Reviewed multi-label topics and explicit taxonomy; mathematics now includes 21 relevant records.
- Conventional article references omit editorial verification history while retaining source-version caveats; audit provenance remains in the evidence database.
- October is presented as the initial publication baseline.
- Shared GitHub star link displays the public live count with a usable offline fallback.

## 2026.10.12 - Project-specific versioned downloads

- Public bibliography files use `does-ai-work-2026.10.12` with their BibTeX, RIS and CSL-JSON extensions. Filtered exports include the same full release version.
- Evidence data, review citations, PDF, archive, methods, licenses and verification reports now have project-specific versioned filenames. A generated file manifest records their names.
- Existing generic URLs and the month-based PDF URL remain compatibility aliases. Previous release archives and published versioned assets are preserved; new archives contain only the current release's files and compatibility aliases.
- Research findings, source counts and the 13 October cutoff are unchanged.

## 2026.10.11 - Leiden Declaration

- Added the Leiden Declaration on Artificial Intelligence and Mathematics with its 16 registered authors, original 2 June 2026 publication date, Zenodo DOI and separate September arXiv version history.
- Verified IMU endorsement against its official circular; endorsers and signatories are not treated as authors or a representative sample.
- Added mathematical governance context to the synthesis, distinguishing normative recommendations from empirical outcomes and recognizing that the declaration is not a blanket AI prohibition.
- Retained the source's separate CC BY-NC rights. Evidence cutoff remains 13 October 2026; prior snapshots are unchanged.

## 2026.10.10 - KPMG primary report and quarterly context

- Added the September Global AI Pulse Q3 2026 PDF with its three explicitly named authors, month-level publication date, survey scope, page-level appraisal and document checksum.
- Appraised the June Q2 announcement separately and linked the waves as one survey family, not independent replications.
- Added reported value versus cost-assessment findings to the business synthesis, qualified by large-firm sampling, executive self-report, early-stage exclusions and noncausal maturity comparisons.
- Added a downloadable appraisal with additional figures and denominators. Cutoff remains 13 October 2026; previous archives are unchanged. Third-party PDF is not redistributed.

## 2026.10.9 - Readable BibTeX commit identifiers

- Abbreviated repository commit IDs to 12 characters in BibTeX notes and pinned repository URLs. Full hashes remain in canonical evidence and verification records, CSL-JSON and RIS; document SHA-256 checksums are unchanged.
- Added the release citation page and desktop back-to-top navigation to the current web presentation.
- Findings, source counts and the 13 October evidence cutoff are unchanged. Previous release archives remain immutable.

## 2026.10.8 - Authorship and publisher corrections

- Resolved the fifteen highlighted missing author credits against primary bylines, recommended citations or institutional credits, keeping publishers separate from named authors.
- Math and AI displays Terence Tao et al.; exports preserve the 25 registered creators in their DataCite order, separate from later signatories and endorsers.
- Anthropic's recommended citation supplies seven authors. KPMG's release is credited institutionally; Steve Chase and Rob Fisher are quoted spokespersons, not established byline authors.
- The February 2026 METR methodological follow-up was already included; strengthened explicit relationships without replacing the original 2025 experiment or duplicating evidence.
- Added authorship provenance and attribution notes to the evidence map and exports. Findings, source counts, cutoff and earlier snapshots are unchanged.

## 2026.10.7 - Repository-backed document dates

- Replaced undated Gravity About, Gravity LLM policy, Zig Code of Conduct and Asahi LLM policy records with dates from source files and Git history.
- Preserved authored/committed timestamps, timezone distinctions and pinned source revisions; publication, revision and policy-adoption dates are not conflated.
- Zig's source-declared document date is 22 November 2025; the inspected policy contains later clarifications. Asahi declares 8 September 2026 despite a 7 September UTC commit.
- Updated citation exports, web evidence map and PDF references. Findings and source counts are unchanged; previous snapshots and the 13 October cutoff are preserved.
- Made repository URLs clickable and long commit identifiers line-breakable in PDF reference notes to prevent margin overflow.

## 2026.10.6 - Open-source contribution boundaries

- Added primary policies for GIMP, NetBSD, Zig, Redox, Asahi, Linux and Gravity, distinguishing scoped prohibitions, default refusal and conditional permission.
- Included the reported Torvalds associative-array episode with test-harness and not-yet-merged caveats; sourced Gravity's stated Asahi-fork rationale to its own FAQ.
- Appraised the 281-policy September study and linked its earlier version and a supporting governance framework; no community-wide prevalence or causal productivity claims.
- Established QEMU's introducing-policy commit date; supplied SWE-bench authors' recommended BibTeX separately from repository and preprint dates.
- Conference exports use BibTeX booktitle and RIS T2. Cutoff remains 13 October 2026; earlier snapshots are preserved.

## 2026.10.5 - DOI registry clarification

- Corrected the Hicks/OSF provenance note after the automated audit successfully retrieved the DOI's Crossref record. The initial DataCite 404 was a lookup in a different registry, not evidence that the DOI was unregistered.
- Preserved the already published 2026.10.4 snapshot and release rather than rewriting its provenance narrative. Findings, source counts, version relationships and 13 October cutoff are unchanged.

## 2026.10.4 - Supplied documents and Chrome version checks

- Resolved three previously unverified study records using PDFs supplied by the human coauthor and actual local Chrome source-page inspections.
- Appraised the chess assistance-design experiment and the AI Skill Threat survey, preserving the specialized-engine/counterfactual distinction and self-report/observational limitations.
- Established SSRN 6996078 and 7070979 as related versions, then appraised the published ESEM paper dated 5 October 2026. One study family; no duplicate replication claims.
- Added a qualified counterpoint to simple agent-induced review-degradation narratives and logged remaining reporting questions.
- Recorded third-party PDF filenames, checksums and reading scopes without redistributing the PDFs. Added four records to the mandatory monthly Chrome watchlist and provenance-validation tests.
- Financial Times remains an unappraised paywalled candidate. Cutoff remains 13 October 2026; previous release snapshots remain unchanged.

## 2026.10.3 - Publication dates and attribution

- Resolved 16 undated checked references using primary bylines, report editions, publisher announcements and structured publication metadata. Retained genuinely undated live documentation and repository entries.
- Distinguished publication from modification, fieldwork and presentation dates. Added date provenance to the evidence map and citation exports.
- Retained the named SWE-bench Verified authors, OpenAI publisher credit, the original 2024 date and separate 2025 update. Appended an actual local Chrome recheck rather than rewriting earlier observations.
- Credited edited-book contributors as editors and added the SEI article and book DOIs.
- Added conservative JSON-LD publication-date extraction and regression tests; related articles, modification-only dates and conflicting dates are not silently accepted.
- No new studies admitted, no empirical conclusions changed, and the evidence cutoff remains 13 October 2026. Earlier release snapshots remain unchanged.

## 2026.10.2 — Local Chrome verification channel

Evidence cutoff: 13 October 2026.

- Inspected 15 selected references in local Chrome and recorded explicit AI-assisted browser receipts, observed metadata, reading scopes and limitations.
- Resolved the Elsevier and CNBC candidates; retained their stable IDs, established the Elsevier DOI, and recovered missing bylines and dates in supporting references.
- Added a monthly Chrome review queue and release gate: a new monthly version requires new inspections; unchanged current-month patch receipts expire after 31 days.
- Added browser-method disclosures to the evidence map, citation exports, downloadable ledger and archived release. Browser confirmations cannot override detected identity conflicts or certify scientific correctness.
- Preserved versions 2026.10.0 and 2026.10.1 and their original artifacts.

## 2026.10.1 — October 2026

Evidence cutoff: 13 October 2026.

- Standardized the publication title to **Does AI Help?** across current website, PDF, citation metadata, and documentation.
- Renamed the current article PDF to `does-ai-help-2026-10.pdf` and updated download links and validation checks.
- Aligned the evidence cutoff with 13 October 2026; preserved authentic historical verification timestamps.
- Added an evidence-weighted balance self-review, October source-admission log, contribution-policy cases, Tao's Math 2.0 discussion and the Navier-Stokes claim/critique chronology.
- Expanded primary engineering evidence on throughput, review load and immediate code comprehension; distinguished secondary reporting from independent studies and retained inaccessible suggestions as candidates.
- Preserved the published 2026.10.0 snapshot and assets; patch releases now use distinct archives and snapshot directories.

## 2026.10.0 — October 2026

Evidence cutoff: 12 October 2026.

- Initial English critical narrative review of productivity, learning, engineering, scientific discovery, organizational value and employment.
- Introduced annotated source records, explicit verification scope, supporting references, unresolved candidates and an exclusions log.
- Added foundational writing and customer-support experiments, specialized AI and scientific-search examples, and newer organization-capital research to broaden coverage beyond engineering.
- Used the September revision of *Writing Code vs. Shipping Code*, including its updated sample and correct authorship: Mert Demirer, Leon Musolff and Liyuan Yang.
- Updated the retail study to its June 2026 title, *Generative AI and Sales Productivity*.
- Distinguished the 2025 Microsoft publication page for the three coding field experiments from later journal metadata.
- Excluded an inherited Goodhart catalog URL that resolved to an unrelated Dutch banking publication.
- Produced a searchable static website, numbered-reference article, XeLaTeX PDF, citation exports, release archive and maintenance workflow.

Publication status: initial AI-authored release, not peer reviewed.
# Initial-release preparation: attribution and reference integrity

- Added Witold Bołt's PhD credential, Jit Team affiliation, contact and LinkedIn in a restrained author note; clarified CC BY 4.0 reuse and third-party rights.
- Added contribution guidance, source/correction issue forms, a PR template and monthly editorial triage. Prepared hosting recommendations without inventing a public repository address.
- Added live title/identifier/registry comparison, PDF identity extraction, expiring documented exceptions, release-blocking checks, metadata provenance reports, and regression tests. Extended access monitoring to website links and DOI landing pages.
- Corrected the Stack Overflow page title, retained explicitly checked shorter registry title aliases, added the SPACE DOI and primary DORA named authors, and documented preprint/publication date differences.
# Pre-publication search for companion syntheses

- Added eleven primary-identified companion sources: OECD productivity review and education outlook, ILO empirical review, Stanford AI Index, ASE productivity-marker review, programming meta-analysis, three educational meta-analyses including a living mathematics review, scientific-agent survey, and CoSLR process study.
- Appraised two existing software/programming-education reviews at abstract level and retained version/evidence-window distinctions.
- Positioned the article alongside existing syntheses and added the disagreement between educational pooling and bias-adjusted results. No new pooled cross-domain estimate or independent replication count is implied.
- Added a transparent search and reading log; extended the all-link checker to external links in publication documents.
# Publication infrastructure

- Configured the does-ai-help organization-site repository, publication URLs, contribution links and citation metadata.
- Kept the publication separate from its earlier working materials; prepared Pages deployment, contribution checks and monthly monitoring.
- Added repository ownership and administration guidance for human editorial and account-security decisions.
